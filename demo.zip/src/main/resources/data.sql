INSERT INTO role (name) VALUES
('Admin');

INSERT INTO users (username, email, password_hash, bio, created_at, role_id) VALUES
('Kelo', 'kevin@gmail.com', 'secreta', 'Bio', CURRENT_TIMESTAMP, 1);